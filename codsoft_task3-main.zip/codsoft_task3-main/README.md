# codsoft_task3
this contains the 3rd and final task of my time as an intern at codsoft
It is a task of customer churn prediction
